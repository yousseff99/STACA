<?PHP
include "produitc.php";
$produitc=new produitc();
?>
<html>
<!DOCTYPE html>

<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    
<!-- Mirrored from html.designstream.co.in/pink-desh/dark/register.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 07 Nov 2019 01:41:45 GMT -->
<head>
        <title>Delete PRODUIT</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"><meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="fontawesome/css/font-awesome.min.css" rel="stylesheet">
        <link href="css/metisMenu.css" rel="stylesheet">
        <link href="css/morris-0.4.3.min.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <script src="js/modernizr.js"></script>
    </head>
    <body class="fixed-left">
<div class="container">
            <div class="row">
                <div class="locksreen-col text-center">
                    <h3>Delete product</h3>
                    <form class="m-t" role="form" method="POST" action="affo.php">
                         <div class="form-group">
                            <input type="text" class="form-control" placeholder="id"  name="idn" required="" >
                        </div>
                        

                        <button type="submit"name="supprimer"  class="btn btn-theme btn-lg btn-block ">supprimer</button><br>
                        
                <p class=" text-center"><small>vous pouvez supprimer un produit!</small></p>
                
                  
                <p>Copyright STACA PRODUCT</p>
                    </form>
                </div>
            </div>
        </div>
        <!-- Plugins  -->
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.slimscroll.js"></script>
        <script src="js/metisMenu.js"></script>
         <script src="js/core.js"></script>
        <script src="js/mediaquery.js"></script>
        <script src="js/equalize.js"></script>
        <script src="js/app.js"></script>

    </body>
</html>
<!-- Mirrored from html.designstream.co.in/pink-desh/dark/register.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 07 Nov 2019 01:41:45 GMT -->
</html>
